/*global document , alert*/
var
    a = document.getElementById("click1"),
    s = document.getElementById("click2"),
    d = document.getElementById("click3"),
    f = document.getElementById("click4"),
    g = document.getElementById("click5");
a.onclick = function () {
    "use strict";
    alert("u have enrolled in the coding course");
};
s.onclick = function () {
    "use strict";
    alert("u have enrolled in the art course");
};
d.onclick = function () {
    "use strict";
    alert("u have enrolled in the business course");
};
f.onclick = function () {
    "use strict";
    alert("u have enrolled in the photograph course");
};
g.onclick = function () {
    "use strict";
    alert("u have enrolled in the logo design course");
};